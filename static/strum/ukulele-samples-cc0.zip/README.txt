Ukulele - Flight Fireball (soprano), 13 sampled positions
=========================================================

Recorded by Mateusz Dąbrowski. Offered to FreePats.

LICENCE
  CC0 1.0 Universal (public domain dedication).
  https://creativecommons.org/publicdomain/zero/1.0/
  No attribution required, though it is always welcome.

FILES
  15 mono WAV, 48000 Hz, 24-bit PCM.

  13 pitched samples, one per position, plus two percussive
  articulations that are part of how a ukulele is actually played:

    body-tap.wav  a knock on the instrument body (0.31 s)
    chuck.wav     a strum into damped strings - the percussive
                  "chk" of a muted stroke (0.16 s)

  Neither is pitched; map them wherever suits the SFZ. In the app they
  sit outside the played range so a strum pattern can call for them.

  C4  D4  E4  F#4  G4  A4  B4  C#5  D#5  F5  G5  A5  C6

  OCTAVE CONVENTION: MIDI 60 = C4, so C4.wav is middle C (261.6 Hz).
  Please confirm against your own convention before generating the
  SFZ - an off-by-one octave is easy to introduce and hard to hear in
  isolation. Every file has been verified by autocorrelation pitch
  detection to match its own filename.

  Roughly one sample every two semitones across the instrument's
  range; the top sample is C6, the 12th fret of the A string.

SOURCE
  Rode Podcaster -> Elgato Wave XLR, captured at 96 kHz / 24-bit mono,
  one room, one session, fixed mic position and gain throughout.
  3-4 takes were recorded per pitch; the take used here is the one
  selected by ear for the app's own SoundFont.

TUNING - PLEASE READ BEFORE GENERATING THE SFZ
  The samples are at their played pitch. They have NOT been
  resampled or pitch-shifted, so nothing has been through an
  interpolation stage. Measured deviation from equal temperament at
  A=440, by autocorrelation on a 16384-sample window:

    C4   +5.0     B4   -0.1     G5   -6.4
    D4   +7.7     C#5  -0.4     A5   -8.5
    E4   +2.4     D#5  -2.7     C6   -3.7
    F#4  +11.4    F5   -4.1
    G4   +1.5

  cents, positive = sharp. The drift from sharp at the bottom to flat
  at the top is the instrument, not the capture: a soprano ukulele
  with the nut compensation it left the factory with.

  If you want these in tune, apply the negated value as the SFZ
  "tune" opcode rather than resampling - e.g. F#4 gets tune=-11.
  The app does exactly this through the SoundFont fine-tune
  generator, which is why it needed no resampling either.

PROCESSING APPLIED
  - Resampled 96 kHz -> 48 kHz (afconvert, highest quality setting).
    24-bit depth carried through from the original capture; nothing
    has been through a 16-bit stage.
  - 6th-order Butterworth high-pass at 190 Hz on the pitched samples.
    A refrigerator compressor in an adjacent room put tonal noise at
    105-140 Hz, close enough to need a steep filter rather than a
    gentle one. 190 Hz still sits below the lowest fundamental here
    (C4, 261.6 Hz), where the filter costs 0.09 dB. Residual energy
    in the 105-140 Hz band now sits 23-36 dB below each sample's own
    peak, and the noise floor measures -68.9 dBFS.
  - body-tap.wav is from the same session and is filtered the same
    way. chuck.wav is NOT filtered: it comes from a separate session
    recorded with the fridge switched off, so there was nothing to
    remove - and a meaningful share of a chuck's energy sits low,
    which is part of the sound rather than noise.
  - Trimmed to the full natural decay, per note rather than a fixed
    length: the scan runs until a 50 ms RMS window reaches twice the
    measured noise floor. That gives 3.25 s at the bottom of the
    range down to 1.10 s at the top, which is the instrument - a
    soprano's short scale gives the upper positions genuinely less
    sustain. These are longer than the versions in the app, which
    truncates for size.
  - 150 ms fade at each tail so the sample end cannot click.
  - Levels matched across notes on a 300 ms window from the attack,
    so the set plays evenly across the range without per-note
    adjustment in the SFZ, then one global gain (+5.2 dB) so the
    loudest peak lands at -3 dBFS. Peaks run -3.0 to -8.4 dBFS; the
    spread is attack transient, not loudness.
  - The two percussive samples are each scaled to -3 dBFS
    individually, since they are not part of that pitched balance.

NOT INCLUDED
  Single velocity layer, one take per pitch or articulation, no
  round-robin alternates. Mono. Two octaves only, C4-C6. An ordinary
  room - treated, but not a studio.

  The sessions do contain 3-4 alternate takes of every pitch and
  around 20 further body taps, so round-robins could be cut from
  existing material if you want them - just ask. Happy to record more
  if that would be useful for the library; the same instrument, room
  and chain are still available.

ALSO AVAILABLE ON REQUEST
  - The untouched 96 kHz / 24-bit captures, if you would rather do
    your own trimming and filtering.
  - The full session including the unused alternate takes.
